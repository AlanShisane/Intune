1. Create batch script executing MSI and MST files using CMD or Powershell script
2. Create a Win32 app 
3. Import Intunewin 
4. Intune install command must point to batch script "msiexec /x "{EFA1C33B-FEEA-4EA9-B58D-E01FE659341A}" /q"  
5. Uninstall command "msiexec /x "{EFA1C33B-FEEA-4EA9-B58D-E01FE659341A}" /q"