Remove-ItemProperty -Path "[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\ClickToRun\Configuration]
"SharedComputerLicensing"="0""